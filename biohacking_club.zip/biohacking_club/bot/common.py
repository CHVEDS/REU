"""
Бизнес-логика, общая для Telegram-бота и бота MAX.

Идея: оба бота — это просто разные "транспорты" (получают сообщения по-своему),
а вся логика регистрации, трекинга привычек и начисления баллов живёт здесь
в виде простых функций, не зависящих от конкретного мессенджера.
"""
from database import db
from config import WEB_BASE_URL

HABIT_CALLBACK_PREFIX = "habit:"  # используется в callback_data инлайн-кнопок


def profile_url(token: str) -> str:
    return f"{WEB_BASE_URL}/profile/{token}"


def get_or_none(platform: str, platform_id) -> dict | None:
    return db.get_user_by_platform(platform, platform_id)


def register_user(platform: str, platform_id, name: str, faculty: str = "", direction: str = "") -> dict:
    existing = db.get_user_by_platform(platform, platform_id)
    if existing:
        return existing
    return db.create_user(platform, platform_id, name, faculty, direction)


def welcome_text(name: str) -> str:
    return (
        f"Привет, {name}! 👋\n\n"
        "Это бот студенческого клуба биохакинга и здоровья.\n"
        "Я помогу отмечать простые ежедневные привычки (сон, вода, "
        "активность, цифровая гигиена) и начислять баллы за твой вклад.\n\n"
        "Команды:\n"
        "/track — отметить привычки на сегодня\n"
        "/profile — мой профиль и баллы\n"
        "/challenge — присоединиться к челленджу «7 дней ресурса»\n"
    )


def build_track_keyboard_data():
    """
    Возвращает список привычек с пометкой, отмечена ли уже привычка сегодня,
    в универсальном виде — конкретный бот сам рисует из этого кнопки.
    """
    return db.list_habits()


def track_options_for_user(user_id: int):
    habits = db.list_habits()
    done_today = db.get_today_logs(user_id)
    options = []
    for h in habits:
        done = h["id"] in done_today
        label = f"✅ {h['title']}" if done else h["title"]
        options.append({"code": h["code"], "label": label, "done": done})
    return options


def handle_habit_log(user_id: int, habit_code: str) -> str:
    ok, message = db.log_habit(user_id, habit_code)
    return message


def profile_text(user: dict) -> str:
    total = db.get_total_points(user["id"])
    history = db.get_habit_history(user["id"], limit=5)
    lines = [
        f"👤 {user['name']}",
        f"Факультет: {user['faculty'] or '—'}",
        f"Направление в клубе: {user['direction'] or '—'}",
        "",
        f"💎 Баллы: {total}",
        "",
        "Последние отметки:",
    ]
    if history:
        for h in history:
            lines.append(f"  {h['log_date']} — {h['title']}")
    else:
        lines.append("  пока нет отметок — используй /track")
    lines.append("")
    lines.append(f"🪪 Личный кабинет («цифровой паспорт»): {profile_url(user['token'])}")
    return "\n".join(lines)


def join_default_challenge(user_id: int) -> str:
    challenge = db.get_default_challenge()
    if not challenge:
        return "Сейчас нет активных челленджей."
    joined = db.join_challenge(user_id, challenge["id"])
    if joined:
        return (
            f"Ты присоединился к челленджу «{challenge['title']}» "
            f"({challenge['duration_days']} дней). Удачи! 💪\n"
            f"{challenge['description']}"
        )
    progress = db.get_challenge_progress(user_id, challenge["id"])
    if progress and not progress["finished"]:
        return (
            f"Ты уже участвуешь в «{challenge['title']}» — "
            f"день {progress['day_number']} из {progress['challenge']['duration_days']}."
        )
    return f"Ты уже завершил челлендж «{challenge['title']}» 🎉"
