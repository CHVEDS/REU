"""
Бот клуба для мессенджера MAX.

Реализован напрямую поверх REST API MAX (без сторонних SDK), чтобы не зависеть
от версии стороннего пакета:
    https://dev.max.ru/docs-api

Использует Long Polling (GET /updates) — это самый простой способ для
локальной разработки, вебхуки для этого не нужны.

Основные вызовы:
    GET  /updates   — получение новых событий (message_created, message_callback, ...)
    POST /messages   — отправка сообщения (?user_id=... или ?chat_id=...)
    POST /answers    — ответ на нажатие инлайн-кнопки (?callback_id=...)

ВАЖНО: MAX Bot API — относительно новый и быстро меняющийся API. Если формат
событий изменится, самый быстрый способ починить бота — включить DEBUG-логи
(logging.DEBUG ниже) и посмотреть, что реально приходит в apdate["message"]/
update["callback"], затем поправить функции _extract_* ниже.

Запуск: python run_max_bot.py
Токен берётся из переменной окружения MAX_BOT_TOKEN (см. .env.example).
"""
import asyncio
import logging

import aiohttp

from config import MAX_BOT_TOKEN, MAX_API_BASE_URL
from database.db import init_db
from bot.common import (
    get_or_none,
    register_user,
    welcome_text,
    track_options_for_user,
    handle_habit_log,
    profile_text,
    join_default_challenge,
)
from bot.registration import registration_manager, STEP_NAME, STEP_FACULTY, STEP_DIRECTION, DIRECTIONS

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("max_bot")

PLATFORM = "max"


class MaxApi:
    """Тонкая обёртка над REST API MAX."""

    def __init__(self, token: str, base_url: str = MAX_API_BASE_URL):
        self.token = token
        self.base_url = base_url.rstrip("/")
        self._session: aiohttp.ClientSession | None = None

    async def __aenter__(self):
        self._session = aiohttp.ClientSession(
            headers={"Authorization": self.token, "Content-Type": "application/json"}
        )
        return self

    async def __aexit__(self, *exc):
        if self._session:
            await self._session.close()

    async def get_updates(self, marker: int | None, timeout: int = 30, limit: int = 100):
        params = {"timeout": timeout, "limit": limit}
        if marker is not None:
            params["marker"] = marker
        async with self._session.get(f"{self.base_url}/updates", params=params) as resp:
            data = await resp.json()
            if resp.status != 200:
                logger.warning("GET /updates -> %s: %s", resp.status, data)
                return [], marker
            return data.get("updates", []), data.get("marker", marker)

    async def send_message(self, text: str, user_id: int = None, chat_id: int = None,
                            keyboard_rows: list | None = None):
        params = {}
        if user_id is not None:
            params["user_id"] = user_id
        if chat_id is not None:
            params["chat_id"] = chat_id
        body = {"text": text, "format": "markdown"}
        if keyboard_rows:
            body["attachments"] = [{"type": "inline_keyboard", "payload": {"buttons": keyboard_rows}}]
        async with self._session.post(f"{self.base_url}/messages", params=params, json=body) as resp:
            data = await resp.json()
            if resp.status not in (200, 201):
                logger.warning("POST /messages -> %s: %s", resp.status, data)
            return data

    async def answer_callback(self, callback_id: str, text: str = None, keyboard_rows: list | None = None):
        message = None
        if text is not None or keyboard_rows is not None:
            message = {"format": "markdown"}
            if text is not None:
                message["text"] = text
            if keyboard_rows:
                message["attachments"] = [{"type": "inline_keyboard", "payload": {"buttons": keyboard_rows}}]
        body = {"message": message} if message else {}
        async with self._session.post(
            f"{self.base_url}/answers", params={"callback_id": callback_id}, json=body
        ) as resp:
            data = await resp.json()
            if resp.status not in (200, 201):
                logger.warning("POST /answers -> %s: %s", resp.status, data)
            return data


def _track_keyboard_rows(user_id: int):
    options = track_options_for_user(user_id)
    return [[{"type": "callback", "text": o["label"], "payload": f"habit:{o['code']}"}] for o in options]


def _directions_keyboard_rows():
    return [[{"type": "callback", "text": d, "payload": f"dir:{i}"}] for i, d in enumerate(DIRECTIONS)]


def _extract_message_created(update: dict):
    """Достаёт (sender_user_id, text) из события message_created."""
    message = update.get("message", {})
    sender = message.get("sender", {}) or {}
    body = message.get("body", {}) or {}
    return sender.get("user_id"), (body.get("text") or "").strip()


def _extract_callback(update: dict):
    """Достаёт (callback_id, user_id, payload) из события message_callback."""
    callback = update.get("callback", {}) or {}
    user = callback.get("user", {}) or {}
    return callback.get("callback_id"), user.get("user_id"), callback.get("payload")


async def _handle_text(api: MaxApi, user_id: int, text: str):
    if text in ("/start", "start", "начать"):
        user = get_or_none(PLATFORM, user_id)
        if user:
            await api.send_message(welcome_text(user["name"]), user_id=user_id)
            return
        registration_manager.start(PLATFORM, user_id)
        await api.send_message(
            "Добро пожаловать в клуб биохакинга и здоровья! 🌱\nКак тебя зовут?",
            user_id=user_id,
        )
        return

    if text in ("/profile", "profile"):
        user = get_or_none(PLATFORM, user_id)
        if not user:
            await api.send_message("Сначала напиши /start", user_id=user_id)
            return
        await api.send_message(profile_text(user), user_id=user_id)
        return

    if text in ("/track", "track"):
        user = get_or_none(PLATFORM, user_id)
        if not user:
            await api.send_message("Сначала напиши /start", user_id=user_id)
            return
        await api.send_message(
            "Отметь, что уже сделал сегодня:", user_id=user_id, keyboard_rows=_track_keyboard_rows(user["id"])
        )
        return

    if text in ("/challenge", "challenge"):
        user = get_or_none(PLATFORM, user_id)
        if not user:
            await api.send_message("Сначала напиши /start", user_id=user_id)
            return
        await api.send_message(join_default_challenge(user["id"]), user_id=user_id)
        return

    # Регистрация в процессе?
    state = registration_manager.get(PLATFORM, user_id)
    if not state:
        await api.send_message(
            "Не понял команду. Доступно: /start, /track, /profile, /challenge", user_id=user_id
        )
        return

    if state.step == STEP_NAME:
        state.name = text[:100]
        state.step = STEP_FACULTY
        await api.send_message("Какой у тебя факультет?", user_id=user_id)
    elif state.step == STEP_FACULTY:
        state.faculty = text[:100]
        state.step = STEP_DIRECTION
        await api.send_message(
            "И последнее — какое направление клуба тебе интереснее?",
            user_id=user_id,
            keyboard_rows=_directions_keyboard_rows(),
        )
    else:
        await api.send_message("Выбери направление кнопкой выше 👆", user_id=user_id)


async def _handle_callback(api: MaxApi, callback_id: str, user_id: int, payload: str):
    if payload is None:
        await api.answer_callback(callback_id)
        return

    if payload.startswith("habit:"):
        user = get_or_none(PLATFORM, user_id)
        if not user:
            await api.answer_callback(callback_id, text="Сначала напиши /start")
            return
        habit_code = payload.split(":", 1)[1]
        result_message = handle_habit_log(user["id"], habit_code)
        await api.answer_callback(
            callback_id,
            text=f"Отметь, что уже сделал сегодня:\n\n{result_message}",
            keyboard_rows=_track_keyboard_rows(user["id"]),
        )
        return

    if payload.startswith("dir:"):
        state = registration_manager.get(PLATFORM, user_id)
        if not state or state.step != STEP_DIRECTION:
            await api.answer_callback(callback_id)
            return
        index = int(payload.split(":", 1)[1])
        state.direction = DIRECTIONS[index]
        user = register_user(PLATFORM, user_id, state.name, state.faculty, state.direction)
        registration_manager.pop(PLATFORM, user_id)
        await api.answer_callback(
            callback_id,
            text=f"Готово! Ты зарегистрирован в направлении «{state.direction}».\n\n" + welcome_text(user["name"]),
        )
        return

    await api.answer_callback(callback_id)


async def main():
    if not MAX_BOT_TOKEN:
        raise RuntimeError(
            "MAX_BOT_TOKEN не задан. Укажите его в .env (получить у @MasterBot в MAX, см. dev.max.ru)."
        )
    init_db()
    marker = None
    async with MaxApi(MAX_BOT_TOKEN) as api:
        logger.info("Бот MAX запущен (long polling)")
        while True:
            try:
                updates, marker = await api.get_updates(marker)
            except Exception:
                logger.exception("Ошибка при получении обновлений, повтор через 3с")
                await asyncio.sleep(3)
                continue

            for update in updates:
                update_type = update.get("update_type")
                try:
                    if update_type == "message_created":
                        user_id, text = _extract_message_created(update)
                        if user_id is not None and text:
                            await _handle_text(api, user_id, text)
                    elif update_type == "message_callback":
                        callback_id, user_id, payload = _extract_callback(update)
                        if callback_id is not None:
                            await _handle_callback(api, callback_id, user_id, payload)
                    elif update_type == "bot_started":
                        user_id, _ = _extract_message_created(update)
                        if user_id is not None:
                            await _handle_text(api, user_id, "/start")
                    else:
                        logger.debug("Пропущено событие типа %s: %s", update_type, update)
                except Exception:
                    logger.exception("Ошибка при обработке события %s", update)


if __name__ == "__main__":
    asyncio.run(main())
