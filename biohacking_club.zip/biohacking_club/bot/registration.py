"""
Простая пошаговая регистрация (мини state-machine в памяти процесса).

Для MVP этого достаточно: если бот перезапустится посреди регистрации,
пользователь просто начнёт её заново командой /start. Состояние не хранится
в БД специально — БД содержит только завершённые профили.
"""
from dataclasses import dataclass, field

STEP_NAME = "name"
STEP_FACULTY = "faculty"
STEP_DIRECTION = "direction"
STEP_DONE = "done"

DIRECTIONS = [
    "Media & Content Lab",
    "Digital & IT Lab",
    "Events & Community",
    "Research & Analytics",
    "Grants & Partnerships",
    "Амбассадор",
]


@dataclass
class RegistrationState:
    step: str = STEP_NAME
    name: str = ""
    faculty: str = ""
    direction: str = ""


class RegistrationManager:
    """Хранит незавершённые регистрации по ключу (platform, platform_id)."""

    def __init__(self):
        self._states: dict[tuple[str, str], RegistrationState] = {}

    def start(self, platform: str, platform_id) -> RegistrationState:
        state = RegistrationState()
        self._states[(platform, str(platform_id))] = state
        return state

    def get(self, platform: str, platform_id) -> RegistrationState | None:
        return self._states.get((platform, str(platform_id)))

    def pop(self, platform: str, platform_id) -> RegistrationState | None:
        return self._states.pop((platform, str(platform_id)), None)


# Общий на весь процесс бота экземпляр
registration_manager = RegistrationManager()
