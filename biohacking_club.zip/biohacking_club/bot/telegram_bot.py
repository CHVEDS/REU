"""
Telegram-бот клуба (библиотека aiogram 3.x).

Запуск: python run_telegram_bot.py
Токен берётся из переменной окружения TELEGRAM_BOT_TOKEN (см. .env.example).
"""
import asyncio
import logging

from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command, CommandStart
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton

from config import TELEGRAM_BOT_TOKEN
from database.db import init_db
from bot.common import (
    get_or_none,
    register_user,
    welcome_text,
    track_options_for_user,
    handle_habit_log,
    profile_text,
    join_default_challenge,
)
from bot.registration import registration_manager, STEP_NAME, STEP_FACULTY, STEP_DIRECTION, DIRECTIONS

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("telegram_bot")

PLATFORM = "telegram"

dp = Dispatcher()


def _track_keyboard(user_id: int) -> InlineKeyboardMarkup:
    options = track_options_for_user(user_id)
    rows = [
        [InlineKeyboardButton(text=o["label"], callback_data=f"habit:{o['code']}")]
        for o in options
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _directions_keyboard() -> InlineKeyboardMarkup:
    rows = [[InlineKeyboardButton(text=d, callback_data=f"dir:{i}")] for i, d in enumerate(DIRECTIONS)]
    return InlineKeyboardMarkup(inline_keyboard=rows)


@dp.message(CommandStart())
async def cmd_start(message: Message):
    user = get_or_none(PLATFORM, message.from_user.id)
    if user:
        await message.answer(welcome_text(user["name"]))
        return
    registration_manager.start(PLATFORM, message.from_user.id)
    await message.answer(
        "Добро пожаловать в клуб биохакинга и здоровья! 🌱\n"
        "Давай познакомимся — как тебя зовут?"
    )


@dp.message(Command("profile"))
async def cmd_profile(message: Message):
    user = get_or_none(PLATFORM, message.from_user.id)
    if not user:
        await message.answer("Сначала пройди регистрацию: /start")
        return
    await message.answer(profile_text(user))


@dp.message(Command("track"))
async def cmd_track(message: Message):
    user = get_or_none(PLATFORM, message.from_user.id)
    if not user:
        await message.answer("Сначала пройди регистрацию: /start")
        return
    await message.answer("Отметь, что уже сделал сегодня:", reply_markup=_track_keyboard(user["id"]))


@dp.message(Command("challenge"))
async def cmd_challenge(message: Message):
    user = get_or_none(PLATFORM, message.from_user.id)
    if not user:
        await message.answer("Сначала пройди регистрацию: /start")
        return
    await message.answer(join_default_challenge(user["id"]))


@dp.callback_query(F.data.startswith("habit:"))
async def cb_habit(callback: CallbackQuery):
    user = get_or_none(PLATFORM, callback.from_user.id)
    if not user:
        await callback.answer("Сначала /start", show_alert=True)
        return
    habit_code = callback.data.split(":", 1)[1]
    result_message = handle_habit_log(user["id"], habit_code)
    await callback.answer(result_message, show_alert=False)
    await callback.message.edit_reply_markup(reply_markup=_track_keyboard(user["id"]))


@dp.callback_query(F.data.startswith("dir:"))
async def cb_direction(callback: CallbackQuery):
    state = registration_manager.get(PLATFORM, callback.from_user.id)
    if not state or state.step != STEP_DIRECTION:
        await callback.answer()
        return
    index = int(callback.data.split(":", 1)[1])
    state.direction = DIRECTIONS[index]
    user = register_user(PLATFORM, callback.from_user.id, state.name, state.faculty, state.direction)
    registration_manager.pop(PLATFORM, callback.from_user.id)
    await callback.message.answer(
        f"Готово! Ты зарегистрирован в направлении «{state.direction}».\n\n" + welcome_text(user["name"])
    )
    await callback.answer()


@dp.message()
async def free_text(message: Message):
    state = registration_manager.get(PLATFORM, message.from_user.id)
    if not state:
        await message.answer("Не понял команду. Список команд: /start, /track, /profile, /challenge")
        return

    if state.step == STEP_NAME:
        state.name = message.text.strip()[:100]
        state.step = STEP_FACULTY
        await message.answer("Какой у тебя факультет?")
    elif state.step == STEP_FACULTY:
        state.faculty = message.text.strip()[:100]
        state.step = STEP_DIRECTION
        await message.answer(
            "И последнее — какое направление клуба тебе интереснее всего?",
            reply_markup=_directions_keyboard(),
        )
    else:
        await message.answer("Выбери направление кнопкой выше 👆")


async def main():
    if not TELEGRAM_BOT_TOKEN:
        raise RuntimeError(
            "TELEGRAM_BOT_TOKEN не задан. Укажите его в .env (получить у @BotFather)."
        )
    init_db()
    bot = Bot(token=TELEGRAM_BOT_TOKEN)
    logger.info("Telegram-бот запущен")
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
