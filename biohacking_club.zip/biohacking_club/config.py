"""
Конфигурация проекта. Значения читаются из переменных окружения (.env),
чтобы токены ботов не хранились в коде.

Перед запуском скопируйте .env.example в .env и заполните значения.
"""
import os
from pathlib import Path

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    # python-dotenv не обязателен: если его нет, просто читаем os.environ как есть
    pass

BASE_DIR = Path(__file__).resolve().parent

# Путь к файлу локальной SQLite базы данных (общий для бота и веб-кабинета)
DB_PATH = os.environ.get("DB_PATH", str(BASE_DIR / "club.sqlite3"))

# Токен Telegram-бота (получить у @BotFather)
TELEGRAM_BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "")

# Токен бота MAX (получить в @MasterBot на dev.max.ru)
MAX_BOT_TOKEN = os.environ.get("MAX_BOT_TOKEN", "")

# Базовый URL API мессенджера MAX
MAX_API_BASE_URL = os.environ.get("MAX_API_BASE_URL", "https://platform-api2.max.ru")

# Базовый URL, по которому будет доступен веб-кабинет (используется ботами,
# чтобы прислать участнику прямую ссылку на его профиль)
WEB_BASE_URL = os.environ.get("WEB_BASE_URL", "http://127.0.0.1:5000")

# Хост/порт для запуска Flask-приложения личного кабинета
WEB_HOST = os.environ.get("WEB_HOST", "127.0.0.1")
WEB_PORT = int(os.environ.get("WEB_PORT", "5000"))
