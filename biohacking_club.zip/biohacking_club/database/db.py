"""
Слой доступа к локальной SQLite базе данных.

База — единственный источник правды, общий для Telegram-бота, бота MAX и
веб-личного кабинета: все три процесса читают и пишут в один файл club.sqlite3.

Схема:
    users                 — профили участников (из Telegram и/или MAX)
    habits                — справочник отслеживаемых привычек
    habit_logs             — история отметок о выполнении привычек
    points_ledger          — журнал начисления баллов (любая запись = +N баллов)
    challenges              — справочник челленджей
    challenge_participants — участие в челлендже и дата старта

SQLite не любит параллельную запись из нескольких потоков/процессов, поэтому
здесь используется WAL-режим (позволяет читать во время записи) и короткие
транзакции: соединение открывается и закрывается на каждый вызов.
"""
import sqlite3
import secrets
import threading
from contextlib import contextmanager
from datetime import date, datetime

from config import DB_PATH

_write_lock = threading.Lock()

# Базовый набор привычек, которые предлагает клуб (см. описание клуба,
# раздел "биохакинг" — сон, движение, питание, цифровая гигиена)
DEFAULT_HABITS = [
    ("sleep", "😴 Сон", "Лёг спать в разумное время / выспался", 1),
    ("water", "💧 Вода", "Выпил достаточно воды за день", 1),
    ("activity", "🏃 Активность", "20+ минут движения / разминка / тренировка", 1),
    ("no_phone", "📵 Цифровая гигиена", "10 минут без телефона перед сном", 1),
]

# Челлендж-пример из описания клуба
DEFAULT_CHALLENGE = ("7 дней ресурса первокурсника",
                      "Каждый день — одно простое действие для сна, энергии и движения.",
                      7)


def _connect():
    conn = sqlite3.connect(DB_PATH, timeout=10, check_same_thread=False)
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA foreign_keys=ON;")
    conn.row_factory = sqlite3.Row
    return conn


@contextmanager
def get_conn():
    """Контекстный менеджер: соединение + автоматический commit/rollback."""
    conn = _connect()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db():
    """Создаёт таблицы (если их ещё нет) и заполняет справочники по умолчанию."""
    with _write_lock, get_conn() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                platform      TEXT NOT NULL,           -- 'telegram' или 'max'
                platform_id   TEXT NOT NULL,           -- id пользователя на этой платформе
                name          TEXT NOT NULL,
                faculty       TEXT,
                direction     TEXT,                    -- направление в клубе (IT, медиа, события, ...)
                token         TEXT UNIQUE NOT NULL,    -- токен для входа в личный кабинет ("цифровой паспорт")
                created_at    TEXT NOT NULL,
                UNIQUE(platform, platform_id)
            );

            CREATE TABLE IF NOT EXISTS habits (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                code          TEXT UNIQUE NOT NULL,
                title         TEXT NOT NULL,
                description   TEXT,
                points_value  INTEGER NOT NULL DEFAULT 1
            );

            CREATE TABLE IF NOT EXISTS habit_logs (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id       INTEGER NOT NULL REFERENCES users(id),
                habit_id      INTEGER NOT NULL REFERENCES habits(id),
                log_date      TEXT NOT NULL,            -- YYYY-MM-DD
                created_at    TEXT NOT NULL,
                UNIQUE(user_id, habit_id, log_date)
            );

            CREATE TABLE IF NOT EXISTS points_ledger (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id       INTEGER NOT NULL REFERENCES users(id),
                amount        INTEGER NOT NULL,
                reason        TEXT NOT NULL,
                created_at    TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS challenges (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                title         TEXT NOT NULL,
                description   TEXT,
                duration_days INTEGER NOT NULL
            );

            CREATE TABLE IF NOT EXISTS challenge_participants (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id       INTEGER NOT NULL REFERENCES users(id),
                challenge_id  INTEGER NOT NULL REFERENCES challenges(id),
                start_date    TEXT NOT NULL,
                UNIQUE(user_id, challenge_id)
            );
            """
        )

        # Справочник привычек — заполняем один раз
        for code, title, description, points in DEFAULT_HABITS:
            conn.execute(
                "INSERT OR IGNORE INTO habits (code, title, description, points_value) "
                "VALUES (?, ?, ?, ?)",
                (code, title, description, points),
            )

        # Пример челленджа
        cur = conn.execute("SELECT COUNT(*) AS c FROM challenges")
        if cur.fetchone()["c"] == 0:
            title, description, days = DEFAULT_CHALLENGE
            conn.execute(
                "INSERT INTO challenges (title, description, duration_days) VALUES (?, ?, ?)",
                (title, description, days),
            )


# ---------------------------------------------------------------------------
# Пользователи
# ---------------------------------------------------------------------------

def get_user_by_platform(platform: str, platform_id: str):
    with get_conn() as conn:
        row = conn.execute(
            "SELECT * FROM users WHERE platform=? AND platform_id=?",
            (platform, str(platform_id)),
        ).fetchone()
        return dict(row) if row else None


def get_user_by_token(token: str):
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM users WHERE token=?", (token,)).fetchone()
        return dict(row) if row else None


def get_user_by_id(user_id: int):
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
        return dict(row) if row else None


def create_user(platform: str, platform_id: str, name: str, faculty: str = "", direction: str = ""):
    token = secrets.token_urlsafe(12)
    now = datetime.utcnow().isoformat(timespec="seconds")
    with _write_lock, get_conn() as conn:
        cur = conn.execute(
            "INSERT INTO users (platform, platform_id, name, faculty, direction, token, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (platform, str(platform_id), name, faculty, direction, token, now),
        )
        user_id = cur.lastrowid
    return get_user_by_id(user_id)


def list_all_users():
    with get_conn() as conn:
        rows = conn.execute("SELECT * FROM users ORDER BY created_at DESC").fetchall()
        return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# Привычки
# ---------------------------------------------------------------------------

def list_habits():
    with get_conn() as conn:
        rows = conn.execute("SELECT * FROM habits ORDER BY id").fetchall()
        return [dict(r) for r in rows]


def get_habit_by_code(code: str):
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM habits WHERE code=?", (code,)).fetchone()
        return dict(row) if row else None


def get_today_logs(user_id: int, log_date: str = None):
    log_date = log_date or date.today().isoformat()
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT habit_id FROM habit_logs WHERE user_id=? AND log_date=?",
            (user_id, log_date),
        ).fetchall()
        return {r["habit_id"] for r in rows}


def log_habit(user_id: int, habit_code: str, log_date: str = None):
    """
    Отмечает привычку выполненной на сегодня и начисляет баллы.
    Возвращает (успех: bool, сообщение: str). Успех = False, если уже
    отмечено сегодня (баллы повторно не начисляются).
    """
    log_date = log_date or date.today().isoformat()
    habit = get_habit_by_code(habit_code)
    if not habit:
        return False, "Такой привычки не существует."

    now = datetime.utcnow().isoformat(timespec="seconds")
    with _write_lock, get_conn() as conn:
        try:
            conn.execute(
                "INSERT INTO habit_logs (user_id, habit_id, log_date, created_at) VALUES (?, ?, ?, ?)",
                (user_id, habit["id"], log_date, now),
            )
        except sqlite3.IntegrityError:
            return False, "Сегодня уже отмечено ✅"

        conn.execute(
            "INSERT INTO points_ledger (user_id, amount, reason, created_at) VALUES (?, ?, ?, ?)",
            (user_id, habit["points_value"], f"habit:{habit_code}:{log_date}", now),
        )
    return True, f"Начислено {habit['points_value']} балл(ов) за «{habit['title']}»"


# ---------------------------------------------------------------------------
# Баллы
# ---------------------------------------------------------------------------

def get_total_points(user_id: int) -> int:
    with get_conn() as conn:
        row = conn.execute(
            "SELECT COALESCE(SUM(amount), 0) AS total FROM points_ledger WHERE user_id=?",
            (user_id,),
        ).fetchone()
        return row["total"]


def add_points(user_id: int, amount: int, reason: str):
    """Ручное начисление баллов (например, руководителем направления)."""
    now = datetime.utcnow().isoformat(timespec="seconds")
    with _write_lock, get_conn() as conn:
        conn.execute(
            "INSERT INTO points_ledger (user_id, amount, reason, created_at) VALUES (?, ?, ?, ?)",
            (user_id, amount, reason, now),
        )


def get_points_history(user_id: int, limit: int = 50):
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM points_ledger WHERE user_id=? ORDER BY created_at DESC LIMIT ?",
            (user_id, limit),
        ).fetchall()
        return [dict(r) for r in rows]


def get_habit_history(user_id: int, limit: int = 30):
    with get_conn() as conn:
        rows = conn.execute(
            """
            SELECT hl.log_date, h.title, h.code
            FROM habit_logs hl
            JOIN habits h ON h.id = hl.habit_id
            WHERE hl.user_id=?
            ORDER BY hl.log_date DESC
            LIMIT ?
            """,
            (user_id, limit),
        ).fetchall()
        return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# Челленджи
# ---------------------------------------------------------------------------

def get_default_challenge():
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM challenges ORDER BY id LIMIT 1").fetchone()
        return dict(row) if row else None


def join_challenge(user_id: int, challenge_id: int):
    today = date.today().isoformat()
    with _write_lock, get_conn() as conn:
        try:
            conn.execute(
                "INSERT INTO challenge_participants (user_id, challenge_id, start_date) VALUES (?, ?, ?)",
                (user_id, challenge_id, today),
            )
            return True
        except sqlite3.IntegrityError:
            return False  # уже участвует


def get_challenge_progress(user_id: int, challenge_id: int):
    with get_conn() as conn:
        part = conn.execute(
            "SELECT * FROM challenge_participants WHERE user_id=? AND challenge_id=?",
            (user_id, challenge_id),
        ).fetchone()
        if not part:
            return None
        challenge = conn.execute(
            "SELECT * FROM challenges WHERE id=?", (challenge_id,)
        ).fetchone()
        start = date.fromisoformat(part["start_date"])
        day_number = (date.today() - start).days + 1
        return {
            "challenge": dict(challenge),
            "start_date": part["start_date"],
            "day_number": max(1, day_number),
            "finished": day_number > challenge["duration_days"],
        }
