"""
Единая точка входа: одним запуском поднимает веб-кабинет и обоих ботов
(Telegram и MAX) в одном процессе.

Если токен бота не задан в .env — этот бот просто пропускается с
предупреждением в логе, остальная система при этом работает нормально.

Обычно не запускается напрямую, а через start.bat (Windows) / start.sh
(Linux/macOS) — они сами создают виртуальное окружение и ставят зависимости.
Но можно и напрямую: python run_all.py (после pip install -r requirements.txt).
"""
import console_utf8  # noqa: F401 — должен быть первым импортом, см. сам файл

import asyncio
import logging
import threading

from config import TELEGRAM_BOT_TOKEN, MAX_BOT_TOKEN, WEB_HOST, WEB_PORT
from database.db import init_db

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(name)s] %(message)s")
logger = logging.getLogger("run_all")


def _run_web():
    from web.app import app
    # use_reloader=False обязателен: встроенный reloader Flask перезапускает
    # процесс целиком и в этой схеме задублировал бы ботов.
    app.run(host=WEB_HOST, port=WEB_PORT, debug=False, use_reloader=False)


async def _run_bot_safely(label: str, coro_factory):
    """
    Запускает бота и ловит любые падения (например, неверный токен, нет
    сети), чтобы одна сломанная интеграция не роняла весь процесс —
    веб-кабинет и второй бот должны продолжать работать.
    """
    try:
        await coro_factory()
    except Exception as exc:  # noqa: BLE001 — сознательно ловим всё подряд
        logger.error("%s остановлен из-за ошибки: %s", label, exc)
        logger.debug("Подробности ошибки %s:", label, exc_info=True)
        logger.error(
            "Проверьте токен в .env и подключение к интернету, затем "
            "перезапустите. Остальная система продолжает работать."
        )


async def _run_bots():
    tasks = []

    if TELEGRAM_BOT_TOKEN:
        from bot.telegram_bot import main as telegram_main
        tasks.append(
            asyncio.create_task(_run_bot_safely("Telegram-бот", telegram_main), name="telegram_bot")
        )
        logger.info("Telegram-бот включён")
    else:
        logger.warning("TELEGRAM_BOT_TOKEN не задан в .env — Telegram-бот не запущен")

    if MAX_BOT_TOKEN:
        from bot.max_bot import main as max_main
        tasks.append(
            asyncio.create_task(_run_bot_safely("Бот MAX", max_main), name="max_bot")
        )
        logger.info("Бот MAX включён")
    else:
        logger.warning("MAX_BOT_TOKEN не задан в .env — бот MAX не запущен")

    if not tasks:
        logger.warning(
            "Ни один токен бота не задан — работает только веб-кабинет "
            "(http://%s:%s). Впишите токены в .env и перезапустите, "
            "чтобы включить ботов.", WEB_HOST, WEB_PORT
        )

    # Держим процесс живым ради веб-потока, даже если оба бота отвалились
    # или их вообще не было — иначе программа сразу завершится.
    while True:
        if tasks:
            await asyncio.gather(*tasks)
            tasks = []  # gather завершился (боты упали и были пойманы) — дальше просто ждём
        else:
            await asyncio.sleep(3600)


def main():
    init_db()

    web_thread = threading.Thread(target=_run_web, daemon=True)
    web_thread.start()
    logger.info("Веб личный кабинет: http://%s:%s", WEB_HOST, WEB_PORT)

    try:
        asyncio.run(_run_bots())
    except KeyboardInterrupt:
        logger.info("Остановлено пользователем")
    except Exception:
        logger.exception("Неожиданная ошибка верхнего уровня — процесс завершается")
        raise


if __name__ == "__main__":
    main()
