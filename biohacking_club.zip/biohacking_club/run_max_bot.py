"""Точка входа: запуск бота MAX. Использование: python run_max_bot.py"""
import console_utf8  # noqa: F401 — должен быть первым импортом, см. сам файл

from bot.max_bot import main
import asyncio

if __name__ == "__main__":
    asyncio.run(main())
