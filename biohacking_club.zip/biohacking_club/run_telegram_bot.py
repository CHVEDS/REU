"""Точка входа: запуск Telegram-бота. Использование: python run_telegram_bot.py"""
import console_utf8  # noqa: F401 — должен быть первым импортом, см. сам файл

from bot.telegram_bot import main
import asyncio

if __name__ == "__main__":
    asyncio.run(main())
