"""Точка входа: запуск веб личного кабинета. Использование: python run_web.py"""
import console_utf8  # noqa: F401 — должен быть первым импортом, см. сам файл

from database.db import init_db
from web.app import app
from config import WEB_HOST, WEB_PORT

if __name__ == "__main__":
    init_db()
    app.run(host=WEB_HOST, port=WEB_PORT, debug=True)
