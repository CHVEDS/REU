@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

rem Switch the console to UTF-8 so Russian text in pip/Python output
rem displays correctly instead of showing garbled characters or crashing.
chcp 65001 >nul
set "PYTHONUTF8=1"

rem --------------------------------------------------------------------
rem Find a real Python interpreter.
rem On many Windows machines "python" in PATH is just the Microsoft Store
rem alias stub (lives under ...\WindowsApps\python.exe). If the actual
rem Store package isn't installed, that stub fails with a generic
rem "cannot find the file specified" error. The "py" launcher (installed
rem by the official python.org installer) does not have this problem, so
rem we prefer it when available.
rem --------------------------------------------------------------------
set "PYCMD="

py -3 -c "import sys" >nul 2>nul
if not errorlevel 1 set "PYCMD=py -3"

if not defined PYCMD (
    python -c "import sys" >nul 2>nul
    if not errorlevel 1 set "PYCMD=python"
)

if not defined PYCMD (
    echo [ERROR] Could not find a working Python interpreter.
    echo.
    echo If "python" opens the Microsoft Store instead of running, that is the
    echo problem: it is a placeholder, not a real Python install.
    echo.
    echo Fix:
    echo   1. Install Python 3.10+ from https://www.python.org/downloads/windows/
    echo      During setup, tick "Add python.exe to PATH".
    echo   2. Then also turn off the Store placeholder:
    echo      Settings ^> Apps ^> Advanced app settings ^> App execution aliases
    echo      switch OFF "python.exe" and "python3.exe".
    echo   3. Close and reopen this terminal, then run start.bat again.
    exit /b 1
)

if not exist venv (
    echo Creating virtual environment using: !PYCMD!
    !PYCMD! -m venv venv
    if errorlevel 1 (
        echo.
        echo [ERROR] Failed to create the virtual environment with "!PYCMD!".
        echo This almost always means that command points to the Microsoft Store
        echo placeholder rather than a real Python install. Fix:
        echo   1. Install Python 3.10+ from https://www.python.org/downloads/windows/
        echo      During setup, tick "Add python.exe to PATH".
        echo   2. Then turn off the Store placeholder:
        echo      Settings ^> Apps ^> Advanced app settings ^> App execution aliases
        echo      switch OFF "python.exe" and "python3.exe".
        echo   3. Close and reopen this terminal, then run start.bat again.
        exit /b 1
    )
)

call venv\Scripts\activate.bat

echo Installing dependencies...
python -m pip install --upgrade pip >nul
pip install -r requirements.txt
if errorlevel 1 (
    echo.
    echo [ERROR] Failed to install dependencies.
    echo If the error above mentions "Microsoft Visual C++ 14.0 or greater is
    echo required" or "linker link.exe not found", it means pip is trying to
    echo compile a package from source because there is no ready-made build
    echo for your Python version yet. Easiest fix: use a slightly older,
    echo widely-supported Python 3.11-3.13 instead of the very newest one.
    echo   1. Install it from https://www.python.org/downloads/windows/
    echo      ^(tick "Add python.exe to PATH"^)
    echo   2. Delete the "venv" folder in this project
    echo   3. Run: py -3.12 -m venv venv   ^(or py -3.11 / py -3.13^)
    echo   4. Run start.bat again
    exit /b 1
)

if not exist .env (
    copy .env.example .env >nul
    echo.
    echo Created .env from .env.example.
    echo Fill in TELEGRAM_BOT_TOKEN and/or MAX_BOT_TOKEN there to enable the bots.
)

echo.
echo Setup complete.
endlocal
