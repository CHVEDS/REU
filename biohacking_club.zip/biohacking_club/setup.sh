#!/usr/bin/env bash
# Ставит виртуальное окружение и зависимости. Использование: ./setup.sh
set -e
cd "$(dirname "$0")"

if ! command -v python3 >/dev/null 2>&1; then
    echo "[ERROR] python3 not found. Install Python 3.10+ and try again."
    exit 1
fi

if [ ! -d venv ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
fi

# shellcheck disable=SC1091
source venv/bin/activate

echo "Installing dependencies..."
pip install --upgrade pip >/dev/null
pip install -r requirements.txt

if [ ! -f .env ]; then
    cp .env.example .env
    echo
    echo "Created .env from .env.example."
    echo "Fill in TELEGRAM_BOT_TOKEN and/or MAX_BOT_TOKEN there to enable the bots."
fi

echo
echo "Setup complete."
