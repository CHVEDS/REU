@echo off
rem One command: sets up the virtual environment and dependencies (if not
rem already done) and starts the web dashboard + both bots.
rem Usage: double-click this file, or run "start.bat" from a terminal.
setlocal
cd /d "%~dp0"

rem Switch the console to UTF-8 so Russian text/emoji in the app's output
rem display correctly instead of crashing or showing garbled characters.
chcp 65001 >nul
set "PYTHONUTF8=1"

call "%~dp0setup.bat"
if errorlevel 1 (
    echo.
    echo Setup failed, aborting.
    pause
    exit /b 1
)

call venv\Scripts\activate.bat
python run_all.py
set "EXIT_CODE=%errorlevel%"
if not "%EXIT_CODE%"=="0" (
    echo.
    echo [ERROR] The app exited with code %EXIT_CODE%. Scroll up for the actual
    echo Python error message ^(it is usually a few lines above this one^).
)

echo.
pause
endlocal
