#!/usr/bin/env bash
# Одна команда: ставит виртуальное окружение и зависимости (если ещё не
# поставлены) и запускает веб-кабинет + обоих ботов.
# Использование: ./start.sh
set -e
cd "$(dirname "$0")"

./setup.sh

# shellcheck disable=SC1091
source venv/bin/activate
python run_all.py
