"""
Веб-личный кабинет клуба (Flask).

Читает данные из той же SQLite базы, что и боты (club.sqlite3), ничего в неё
не пишет, кроме ручного начисления баллов администратором.

У каждого участника есть персональная ссылка вида /profile/<token> — это и
есть его «цифровой паспорт участника». Токен выдаётся автоматически при
регистрации в любом из ботов (Telegram или MAX) и приходит в сообщении /profile.

Запуск: python run_web.py
"""
from flask import Flask, render_template, abort, request, redirect, url_for, flash

from config import WEB_HOST, WEB_PORT
from database import db

app = Flask(__name__)
app.secret_key = "dev-secret-key-change-me"  # для flash-сообщений; не критично для локального запуска


@app.route("/")
def index():
    """Админ-страница: список всех участников (для локального использования)."""
    users = db.list_all_users()
    users_with_points = [
        {**u, "points": db.get_total_points(u["id"])} for u in users
    ]
    return render_template("index.html", users=users_with_points)


@app.route("/profile/<token>")
def profile(token):
    user = db.get_user_by_token(token)
    if not user:
        abort(404)
    total_points = db.get_total_points(user["id"])
    habit_history = db.get_habit_history(user["id"], limit=30)
    points_history = db.get_points_history(user["id"], limit=30)
    habits = db.list_habits()
    today_done = db.get_today_logs(user["id"])

    challenge = db.get_default_challenge()
    challenge_progress = None
    if challenge:
        challenge_progress = db.get_challenge_progress(user["id"], challenge["id"])

    return render_template(
        "profile.html",
        user=user,
        total_points=total_points,
        habit_history=habit_history,
        points_history=points_history,
        habits=habits,
        today_done=today_done,
        challenge=challenge,
        challenge_progress=challenge_progress,
    )


@app.route("/admin/add_points/<int:user_id>", methods=["POST"])
def admin_add_points(user_id):
    """Простая форма для ручного начисления баллов (например, за офлайн-мероприятие)."""
    user = db.get_user_by_id(user_id)
    if not user:
        abort(404)
    try:
        amount = int(request.form.get("amount", "0"))
    except ValueError:
        amount = 0
    reason = request.form.get("reason", "").strip() or "manual"
    if amount:
        db.add_points(user_id, amount, reason)
        flash(f"Начислено {amount} балл(ов) участнику {user['name']}")
    return redirect(url_for("index"))


@app.errorhandler(404)
def not_found(_e):
    return render_template("404.html"), 404


if __name__ == "__main__":
    from database.db import init_db

    init_db()
    app.run(host=WEB_HOST, port=WEB_PORT, debug=True)
